package Facade;

class CarFacade {
    private Door door = new Door();

    public void go(){
        door.close();
    }
}
