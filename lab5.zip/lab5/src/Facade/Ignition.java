package Facade;

public class Ignition {

    public void fire() {
        System.out.println("fire");
    }
}

