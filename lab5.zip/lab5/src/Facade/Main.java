package Facade;

public class Main {
    public static void main(String[] args) {

        Door door = new Door();
        door.open();

        Ignition ignition = new Ignition();
        ignition.fire();

        Wheel wheel = new Wheel();
        wheel.turn();

        CarFacade carFacade = new CarFacade();
        carFacade.go();
    }
}

