package Facade;

import javax.xml.bind.SchemaOutputResolver;

class Door{
    public void open() {
        System.out.println("door opened");
    }

    public void close() {
        System.out.println("door closed");
    }
}