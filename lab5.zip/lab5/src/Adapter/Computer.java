package Adapter;

public interface Computer {
    void insertIntoLightningPort();
}