package Adapter;

public class Windows {

    void insertIntoUSBPort(){
        System.out.println("USB connector is plugged into Windows\n");

    }
}
