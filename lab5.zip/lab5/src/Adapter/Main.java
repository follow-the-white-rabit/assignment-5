package Adapter;

public class Main {

    public static void main(String[] args) {
        Client client = new Client();
        MacOS myMac = new MacOS();
        Windows myWin = new Windows();
        WindowsAdapter adapter = new WindowsAdapter(myWin);
        MacOSAdapter adapter1 = new MacOSAdapter(myMac);

        client.insertLightningConnectorIntoComputer(adapter);
        client.insertUSBPortIntoComputer(adapter1);

    }
}