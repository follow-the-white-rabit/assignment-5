package Adapter;

public class Client {

    public void insertLightningConnectorIntoComputer(Computer com){
        System.out.println("Client inserts Lightning connector into computer");
        com.insertIntoLightningPort();
    }

    public void insertUSBPortIntoComputer(Computer1 com){
        System.out.println("Client inserts USB connector into computer");
        com.insertUSBPort();
    }

}
