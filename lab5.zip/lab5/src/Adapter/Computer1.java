package Adapter;

public interface Computer1 {
    void insertUSBPort();
}
