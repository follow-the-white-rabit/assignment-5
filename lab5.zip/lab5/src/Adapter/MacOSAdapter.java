package Adapter;

public class MacOSAdapter implements Computer1{

    private MacOS macOS;

    public MacOSAdapter(MacOS macOS){
        this.macOS = macOS;
    }


    @Override
    public void insertUSBPort(){
        System.out.println("Adapter converts USB signal to Lightning");
        macOS.insertIntoLightningPort();
    }
}
