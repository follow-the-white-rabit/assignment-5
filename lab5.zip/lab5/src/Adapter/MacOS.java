package Adapter;

public class MacOS{

    void insertIntoLightningPort() {
        System.out.println("Lightning connector is plugged into macOS\n");
    }
}
