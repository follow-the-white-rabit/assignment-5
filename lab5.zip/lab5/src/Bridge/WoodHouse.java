package Bridge;

public class WoodHouse implements IHouse {
    @Override
    public String material() {
        return "I Am Wood";
    }

    @Override
    public int power() {
        return 15;
    }
}
