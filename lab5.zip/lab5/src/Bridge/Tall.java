package Bridge;

public class Tall extends HouseType {

    public Tall(IHouse iHouse) {
        super(iHouse);

        setName(iHouse.material()+" Tall House");

        iHouse.material();

        setPower(30+iHouse.power());
    }
}
