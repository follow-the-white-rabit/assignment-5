package Bridge;

public abstract class HouseType {
    IHouse iHouse = null;
    String name = "";
    int power = 0;

    public HouseType(IHouse iHouse) {
        this.iHouse = iHouse;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int pow) {
        this.power = pow;
    }
}
