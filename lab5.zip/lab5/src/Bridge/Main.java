package Bridge;

public class Main {
    public static void main(String[] arg) {

        HouseType house = new Cave(new WoodHouse());
        System.out.printf(house.getName()+"\t"+house.getPower()+"\n");

        house = new Cave(new BrickHouse());
        System.out.printf(house.getName()+"\t"+house.getPower()+"\n");

        house = new Cave(new MetalHouse());
        System.out.printf(house.getName()+"\t"+house.getPower()+"\n");

        house = new Tall(new WoodHouse());
        System.out.printf(house.getName()+"\t"+house.getPower()+"\n");

        house = new Small(new MetalHouse());
        System.out.printf(house.getName()+"\t"+house.getPower()+"\n");

    }
}
