package Bridge;

public class BrickHouse implements IHouse {

    @Override
    public String material() {
        return "I Am Brick";
    }

    @Override
    public int power() {
        return 50;
    }
}
