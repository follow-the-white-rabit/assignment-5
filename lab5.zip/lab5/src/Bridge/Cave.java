package Bridge;

public class Cave extends HouseType {

    public Cave(IHouse iHouse) {
        super(iHouse);

        setName(iHouse.material()+" Cave");

        setPower(100+iHouse.power());
    }
}
