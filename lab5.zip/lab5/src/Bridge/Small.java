package Bridge;

public class Small extends  HouseType {

    public Small(IHouse iHouse) {
        super(iHouse);
        setName(iHouse.material()+" Small House");

        iHouse.material();

        setPower(50+iHouse.power());
    }
}