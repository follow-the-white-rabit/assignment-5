package Bridge;

public interface IHouse {
    public String material();
    public int power();


}
