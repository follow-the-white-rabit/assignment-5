package Bridge;

public class MetalHouse implements IHouse {
    @Override
    public String material() {
        return "I Am Metal";
    }

    @Override
    public int power() {
        return 100;
    }
}
